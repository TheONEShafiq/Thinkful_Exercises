-- Query to inspect the schema to get list of column names and descriptions
SELECT 
	column_name,
	is_nullable, 
	data_type
FROM 
	information_schema.COLUMNS
WHERE 
	table_name = 'useducation'