-- Query returning the first 50 records of the table
SELECT  
	*
FROM 
	useducation
LIMIT 50