-- Write a query that returns a field called bottom_10_states that lists the states 
-- in the bottom 10 for avg_math_4_score in the year 2000.

SELECT 
	"STATE",
	avg("AVG_MATH_4_SCORE") as "bottom_10"
FROM 
	USEDUCATION
WHERE 
	"YEAR" = 2000
GROUP BY "STATE"
ORDER BY "bottom_10" ASC 
LIMIT 10