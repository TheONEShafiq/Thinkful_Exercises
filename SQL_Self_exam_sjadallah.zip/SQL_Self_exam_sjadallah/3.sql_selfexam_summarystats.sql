--Write a query that returns summary statistics for avg_math_4_score by state. 
-- Make sure to sort the results alphabetically by state name.

SELECT 
	"STATE",
	COUNT("AVG_MATH_4_SCORE"),
	min("AVG_MATH_4_SCORE"),
	max("AVG_MATH_4_SCORE"),
	avg("AVG_MATH_4_SCORE")
FROM 
	USEDUCATION
GROUP BY "STATE"
ORDER BY "STATE" ASC 
	