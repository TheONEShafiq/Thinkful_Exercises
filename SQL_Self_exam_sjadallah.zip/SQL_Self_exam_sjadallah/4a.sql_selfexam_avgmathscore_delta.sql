-- Write a query that alters the previous query so that it returns only 
-- the summary statistics for avg_math_4_score by state with 
--differences in max and min values that are greater than 30.
SELECT 
	"STATE",
	max("AVG_MATH_4_SCORE") - min("AVG_MATH_4_SCORE") AS "AVG_MATH_4_SCORE"
FROM 
	USEDUCATION
WHERE 
	"AVG_MATH_4_SCORE" >= 30
GROUP BY "STATE"
ORDER BY "STATE" ASC 