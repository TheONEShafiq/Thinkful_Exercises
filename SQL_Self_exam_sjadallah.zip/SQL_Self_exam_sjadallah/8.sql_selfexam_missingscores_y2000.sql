-- Write a query that returns a field called scores_missing_y2000 that lists 
--any states with missing values in the avg_math_4_score column of the naep 
--data table for the year 2000.

SELECT 
	"STATE",
	avg("AVG_MATH_4_SCORE") as "scores_missing_y2000"
FROM 
	USEDUCATION
WHERE 
	"YEAR" = 2000
	AND "AVG_MATH_4_SCORE" IS null
GROUP BY "STATE"
ORDER BY "STATE" ASC 