-- Write a query that calculates the average avg_math_4_score rounded 
-- to the nearest 2 decimal places over all states in the year 2000.

SELECT 
	"STATE",
	ROUND(avg("AVG_MATH_4_SCORE")::numeric, 2) as "avg_score"
FROM 
	USEDUCATION
WHERE 
	"YEAR" = 2000
	AND "AVG_MATH_4_SCORE" IS NOT null
GROUP BY "STATE"
ORDER BY "avg_score" DESC 