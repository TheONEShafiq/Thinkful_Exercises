-- Write a query that returns a field called below_average_states_y2000 that lists 
-- all states with an avg_math_4_score less than the average over all states in the year 2000.
SELECT 
	"STATE",
	ROUND(avg("AVG_MATH_4_SCORE")::numeric,2) as "below_avg_states_y2000"
FROM 
	USEDUCATION
WHERE 
	"YEAR" = 2000
	AND "AVG_MATH_4_SCORE" IS NOT null
	AND "AVG_MATH_4_SCORE" < (SELECT AVG("AVG_MATH_4_SCORE") FROM useducation)
GROUP BY "STATE"
ORDER BY "STATE" ASC 

